<?php

include_once ALLSTON_CORE_SHORTCODES_PATH . '/animation-holder/functions.php';
include_once ALLSTON_CORE_SHORTCODES_PATH . '/animation-holder/animation-holder.php';