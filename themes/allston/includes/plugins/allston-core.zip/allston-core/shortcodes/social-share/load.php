<?php

include_once ALLSTON_CORE_SHORTCODES_PATH . '/social-share/functions.php';
include_once ALLSTON_CORE_SHORTCODES_PATH . '/social-share/social-share.php';