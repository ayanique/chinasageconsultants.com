<?php
/**
 * Highlight shortcode template
 */
?>

<span class="eltdf-highlight" <?php allston_eltdf_inline_style($highlight_style);?>>
	<?php echo esc_html($content);?>
</span>