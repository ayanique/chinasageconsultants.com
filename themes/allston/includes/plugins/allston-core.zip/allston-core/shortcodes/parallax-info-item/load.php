<?php

include_once ALLSTON_CORE_SHORTCODES_PATH . '/parallax-info-item/functions.php';
include_once ALLSTON_CORE_SHORTCODES_PATH . '/parallax-info-item/parallax-info-item.php';