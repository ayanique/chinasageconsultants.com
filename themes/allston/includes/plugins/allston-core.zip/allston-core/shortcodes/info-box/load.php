<?php

include_once ALLSTON_CORE_SHORTCODES_PATH . '/info-box/functions.php';
include_once ALLSTON_CORE_SHORTCODES_PATH . '/info-box/info-box.php';
include_once ALLSTON_CORE_SHORTCODES_PATH . '/info-box/info-box-item.php';