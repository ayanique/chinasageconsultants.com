<?php

include_once ALLSTON_CORE_SHORTCODES_PATH . '/swaying-image/functions.php';
include_once ALLSTON_CORE_SHORTCODES_PATH . '/swaying-image/swaying-image.php';