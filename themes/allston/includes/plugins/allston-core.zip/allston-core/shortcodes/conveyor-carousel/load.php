<?php

include_once ALLSTON_CORE_SHORTCODES_PATH . '/conveyor-carousel/functions.php';
include_once ALLSTON_CORE_SHORTCODES_PATH . '/conveyor-carousel/conveyor-carousel.php';