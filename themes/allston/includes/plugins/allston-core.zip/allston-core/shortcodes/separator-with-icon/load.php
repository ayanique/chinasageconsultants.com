<?php

include_once ALLSTON_CORE_SHORTCODES_PATH.'/separator-with-icon/functions.php';
include_once ALLSTON_CORE_SHORTCODES_PATH.'/separator-with-icon/separator-with-icon.php';

