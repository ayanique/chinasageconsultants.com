<?php

include_once ALLSTON_CORE_SHORTCODES_PATH . '/dropcaps/functions.php';
include_once ALLSTON_CORE_SHORTCODES_PATH . '/dropcaps/dropcaps.php';