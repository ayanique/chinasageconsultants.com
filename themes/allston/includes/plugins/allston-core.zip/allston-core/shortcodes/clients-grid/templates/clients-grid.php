<div class="eltdf-clients-grid-holder <?php echo esc_attr( $holder_classes ); ?>">
	<div class="eltdf-cg-inner eltdf-outer-space">
		<?php echo do_shortcode( $content ); ?>
	</div>
</div>