<?php

include_once ALLSTON_CORE_SHORTCODES_PATH . '/interactive-image-box/functions.php';
include_once ALLSTON_CORE_SHORTCODES_PATH . '/interactive-image-box/interactive-image-box.php';
include_once ALLSTON_CORE_SHORTCODES_PATH . '/interactive-image-box/interactive-image-box-item.php';