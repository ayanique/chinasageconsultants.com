<?php

include_once ALLSTON_CORE_SHORTCODES_PATH . '/presentation-extended/functions.php';
include_once ALLSTON_CORE_SHORTCODES_PATH . '/presentation-extended/presentation-extended.php';