<?php

get_header();

allston_eltdf_get_title();

do_action('allston_eltdf_before_main_content');

allston_core_get_single_portfolio();

get_footer();