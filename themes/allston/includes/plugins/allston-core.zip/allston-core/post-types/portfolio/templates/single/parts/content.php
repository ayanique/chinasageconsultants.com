<div class="eltdf-ps-content-item">
    <?php the_content(); ?>
</div>