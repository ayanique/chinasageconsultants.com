<div class="eltdf-pfs-image-holder-item">
	<div class="eltdf-pfs-image"  <?php allston_eltdf_inline_style($this_object->getItemBackgroundImage())?>>
		<div class="eltdf-pfs-text-holder">
			<div class="eltdf-pfs-text-holder-inner">
			</div>
		</div>
	</div>
</div>