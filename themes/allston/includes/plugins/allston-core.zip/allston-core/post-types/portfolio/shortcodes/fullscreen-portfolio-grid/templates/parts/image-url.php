<div class="eltdf-image-url-holder-inner">
	<div class="eltdf-image-url" <?php allston_eltdf_inline_style($this_object->getItemBackgroundImage())?>></div>
</div>