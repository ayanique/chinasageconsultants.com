<div class="eltdf-ps-content-title">
    <h2 class="eltdf-ps-info-main-title"><?php the_title(); ?></h2>
    <?php echo do_shortcode( '[eltdf_separator]' ); ?>
</div>