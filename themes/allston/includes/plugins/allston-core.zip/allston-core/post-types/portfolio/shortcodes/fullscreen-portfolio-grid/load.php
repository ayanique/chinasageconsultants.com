<?php

require_once 'fullscreen-portfolio-grid.php';
require_once 'helper-functions.php';